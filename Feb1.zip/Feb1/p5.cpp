//Author:Mr. Palani Karthikeyan
//------------------------------
#include<iostream>
using namespace std;

int main(){
	cout<<"10+20.5\t"<<10+20<<endl;
	cout<<"10+20.5\t"<<10+20.5<<endl;
	return 0;
}
