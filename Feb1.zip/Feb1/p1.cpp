/* Welcome to C++ code
   Author:Mr.Palani Karthikeyan
*/
#include<iostream>
using namespace std;

int main(){
	cout<<"Welcome to C++ Programming\n";
	return 0;
}
