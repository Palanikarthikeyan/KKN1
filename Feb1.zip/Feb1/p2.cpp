/*
Topic:variable usages
----------------------
Author:Palani Karthikeyan
Description:-
--------------
Variable is an identifier,which is holding value,
i.e, which is associated with value.

Syntax:-
--------
data_type variable_name=value;
*/
#include<iostream>
using namespace std;
int main(){
	int empid=1234;
	float cost=433523.56;
	
	cout<<"EMP ID:"<<empid<<endl;
	cout<<"COST:"<<cost<<endl;
	return 0;
}



